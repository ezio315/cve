# Stack-Based Out-of-Bounds Write in `ripd` via Local zserv IPC in Tomato by Shibby

## 1. Proposed Title

Stack-based out-of-bounds write in `usr/sbin/ripd` in `Tomato by Shibby` firmware

## 2. Affected Product

- Product family: `Tomato by Shibby` firmware
- Affected component: `usr/sbin/ripd`
- Verified version line: `Tomato v1.28.0005 124 ND USB`
- Verified official packages:
  - `tomato-NDUSB-1.28.5x-124-Nocat-VPN.trx`
  - `tomato-NDUSB-1.28.5x-124-BT-VPN.trx`
- Public package index:
  - <https://tomato.groov.pl/download/K24/build5x-124-EN/>

## 3. Vulnerability Type

- Stack-based Buffer Overflow
- Out-of-bounds Write
- CWE:
  - `CWE-121`
  - `CWE-787`

## 4. Vulnerability Description

`ripd` receives zebra routing updates over the local Unix domain socket `/tmp/.zserv`. In the `rip_zebra_read_ipv4` receive path, the daemon reads an attacker-controlled one-byte prefix length, computes `((plen + 7) >> 3)`, and uses that value as the byte count for a stack copy into a region that has only about 8 safe bytes before saved registers begin.

Because the implementation does not clamp IPv4 prefix length to `<= 32` and does not validate the derived byte count against the actual local destination size, a crafted zserv frame can overwrite saved registers and the saved return address.

## 5. Root Cause

Verified vulnerable logic:

- `zclient_start` connects to `/tmp/.zserv`
- `zclient_read`
- `rip_zebra_read_ipv4`
- `stream_get(sp + 0x30, stream, ((plen + 7) >> 3))`

The root cause can be summarized as:

```c
uint8_t plen = stream_getc(stream);
size_t copy_len = (plen + 7) >> 3;
stream_get(sp_30, stream, copy_len);
```

The local destination beginning at `sp + 0x30` does not have enough space for unbounded `copy_len` values. Static thresholds derived from the verified stack layout are:

- `plen >= 65` begins overwriting saved registers
- `plen >= 225` reaches saved `ra`
- `plen >= 249` can fully cover the 4-byte saved `ra`

See `./supporting/static_root_cause.md`.

## 6. Runtime Verification

Validation was performed by running the extracted MIPS `ripd` binary under `qemu-mipsel` and emulating the expected zebra peer with a fake Unix socket server bound at `/tmp/.zserv`.

Minimal on-wire shape:

```text
len(2) | cmd(1) | type(1) | unused(1) | message(1) | plen(1) | prefix bytes
```

Verified benign frame:

```text
000a07010000180a0000
```

Verified crashing frame pattern:

```text
002707010000ff4141414141414141414141414141414141414141414141414141414141414141
```

Observed runtime effects:

1. `ripd` connects to `/tmp/.zserv` and sends startup frame `000301`.
2. The benign route-add frame is accepted through the same path.
3. Replacing the benign frame with a `plen=255` frame immediately crashes `ripd` after the two expected `read` operations.
4. Changing only the fill byte changes the observed fault pattern:
   - fill byte `0x41` -> `SIGSEGV`, `si_addr=0x41414140`
   - fill byte `0x42` -> `SIGSEGV`, `si_addr=0x42424242`

Threshold probing further produced:

- `plen=224` -> `SIGBUS`, `si_addr=0x43434343`
- `plen=225` -> `SIGSEGV`, `si_addr=0x00000032`

See `./supporting/dynamic_verified.md`.

## 7. GDB Evidence

A dedicated GDB-assisted run captured the vulnerable copy site immediately before and after the `stream_get` call.

Before copy:

- stack region near `sp+0x30` still contains ordinary local values
- saved state is not yet overwritten

After copy with `plen=255` and fill byte `0x44`:

- bytes from `sp+0x30` upward become a contiguous `0x44` pattern
- saved register words at `sp+0x38` become `0x44444444`
- the saved return-address word at `sp+0x4c` becomes `0x44444444`

Bundled evidence:

- terminal screenshot: 



- reproduction helper: `./repro/run_fake_zserv.py`
- GDB input file: `./repro/gdb_capture_cmds.txt`
- GDB wrapper script: `./repro/run_ripd_gdb_capture.sh`
- raw transcript: `./supporting/gdb_capture_plen255.txt`

## 8. Attack Surface Statement

The current evidence supports a conservative local boundary statement only.

In the validated environment:

- the paired `zebra` process ran as `uid=0 gid=0`
- `/tmp/.zserv` was root-owned and observed as mode `0700`

Accordingly, the presently supported statement is:

- `local privileged / same-host IPC boundary`

Additional static product-line evidence indicates that authenticated administrative interfaces can indirectly influence the same routing control plane. In particular, routing-related management pages expose RIP configuration knobs and service-restart actions, while the product-line service logic contains direct zebra/ripd startup and configuration strings. In deployments where remote administrative access is enabled, an authenticated remote administrator may therefore be able to reach the same routing control plane indirectly. This administrative bridge is not yet dynamically validated on the verified sample, so it is not treated as the primary attack vector in this submission.

The current evidence does **not** support:

- remote reachability
- unauthenticated network exploitation
- low-privilege local reachability
- reliable code execution

See `./supporting/runtime_socket_mode.txt`.
See also `./supporting/admin_plane_bridge.md`.

## 9. Security Impact

The current evidence supports the following impact:

- local denial of service of `ripd`
- corruption of saved registers and saved return-address state on the zebra-to-ripd IPC boundary
- potential control-flow corruption inside the same-host routing IPC trust boundary

## 10. Suggested Mitigation

- reject IPv4 route messages with `plen > 32` before any prefix-byte copy
- validate `((plen + 7) >> 3)` against the actual destination size
- replace the raw stack copy with a fixed-size prefix structure and explicit length checks
- audit sibling zebra IPC handlers for the same `plen -> ceil(plen/8)` copy pattern

## 11. Bundled Evidence

- `./supporting/README.md`
- `./supporting/static_root_cause.md`
- `./supporting/dynamic_verified.md`
- `./supporting/gdb_capture_plen255.txt`
- `./supporting/runtime_socket_mode.txt`
- `./supporting/admin_plane_bridge.md`
- `./repro/run_fake_zserv.py`
- `./repro/gdb_capture_cmds.txt`
- `./repro/run_ripd_gdb_capture.sh`
- `./repro/README.md`
- `./evidence/gdb_before_after_copy_terminal.png`
- `./evidence/fake_zserv_payload_terminal.png`
