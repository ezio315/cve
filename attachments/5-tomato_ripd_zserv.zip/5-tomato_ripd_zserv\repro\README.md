# Reproduction Helper

This directory contains a minimal helper used during validation of the `rip_zebra_read_ipv4` overflow.

Included files:

- `run_fake_zserv.py`
  - minimal fake zebra server for `/tmp/.zserv`
- `gdb_capture_cmds.txt`
  - GDB command file used to capture the before/after stack state at the vulnerable copy site
- `run_ripd_gdb_capture.sh`
  - helper wrapper for running `ripd` under `qemu-mipsel -g` and attaching `gdb-multiarch`

Usage outline:

1. Start `ripd` in an environment where it connects to `/tmp/.zserv`.
2. Launch:

```bash
python3 ./repro/run_fake_zserv.py --plen 255 --fill-byte 0x44
```

3. The helper will:
   - listen on `/tmp/.zserv`
   - accept the client connection
   - read the initial startup frame(s)
   - send a crafted `cmd=7` route-add frame carrying the chosen `plen`

GDB helper usage outline:

```bash
export ROOTFS=/path/to/extracted-rootfs
export RIPD_BIN=/path/to/usr/sbin/ripd
export CASE_DIR=/path/to/writable-case-dir
./repro/run_ripd_gdb_capture.sh
```

Before use, replace the placeholders in `gdb_capture_cmds.txt`:

- `__ROOTFS__`
- `__RIPD_BIN__`

Notes:

- The helper is intentionally generic and does not bundle the full runtime environment.
- The validated on-wire layout for the delivered payload is documented in `../supporting/dynamic_verified.md`.
