# `ripd` Local IPC Overflow Submission Package

This directory is the cleaned submission package for the verified `rip_zebra_read_ipv4` stack-based out-of-bounds write in `ripd` from `Tomato by Shibby`.

Use:

- `CVE_Submission_en.md` for CVE / English submission
- `CNVD_Submission_zh.md` for CNVD / 中文提交

Verified product line:

- Product family: `Tomato by Shibby`
- Version line: `Tomato v1.28.0005 124 ND USB`
- Verified official packages:
  - `tomato-NDUSB-1.28.5x-124-Nocat-VPN.trx`
  - `tomato-NDUSB-1.28.5x-124-BT-VPN.trx`

Current conclusion:

- The issue is a stack-based out-of-bounds write in `usr/sbin/ripd`.
- The validated trigger path is the local zebra-to-ripd Unix socket `/tmp/.zserv`.
- The current evidence supports `local privileged / same-host IPC boundary`.
- Product-line static evidence also supports a narrower secondary note: authenticated administrative interfaces can indirectly influence the same routing control plane, especially when remote management is enabled.
- The current evidence does not support `remote`, `low-privilege local`, or `reliable RCE` wording.

Included files:

- `evidence/gdb_before_after_copy_terminal.png`
  - real terminal screenshot showing GDB before/after stack state and `saved_ra_word=0x44444444`
- `evidence/fake_zserv_payload_terminal.png`
  - real terminal screenshot showing the fake `/tmp/.zserv` payload delivered during validation
- `repro/run_fake_zserv.py`
  - minimal fake zebra server used to deliver the crafted `/tmp/.zserv` frame
- `repro/gdb_capture_cmds.txt`
  - GDB input file used to capture the stack immediately before and after the vulnerable copy
- `repro/run_ripd_gdb_capture.sh`
  - helper wrapper for running `ripd` under qemu gdbstub and attaching `gdb-multiarch`
- `repro/README.md`
  - quick usage notes for the bundled reproduction helper
- `supporting/gdb_capture_plen255.txt`
  - raw GDB transcript proving saved stack state and saved `ra` overwrite
- `supporting/dynamic_verified.md`
  - runtime setup, malicious zserv frames, crash results, and threshold probing
- `supporting/static_root_cause.md`
  - static receive path, stack layout, overwrite thresholds, and variant spread
- `supporting/runtime_socket_mode.txt`
  - socket ownership and permission evidence for the conservative attack-surface statement
- `supporting/admin_plane_bridge.md`
  - static note describing the authenticated management-plane bridge into the same routing control plane
- `supporting/README.md`
  - supporting evidence index

Notes:

- All paths referenced from the two submission drafts are relative to this directory.
- Extracted rootfs trees and helper runtime scripts are not bundled here because they are large and only needed to reproduce the validation environment.
- The raw transcript `supporting/gdb_capture_plen255.txt` is the canonical bundled GDB artifact for this package.
