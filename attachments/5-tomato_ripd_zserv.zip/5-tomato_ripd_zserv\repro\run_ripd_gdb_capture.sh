#!/bin/sh
set -eu

: "${ROOTFS:?set ROOTFS to the extracted Tomato rootfs directory}"
: "${RIPD_BIN:?set RIPD_BIN to the target ripd binary path}"
: "${CASE_DIR:?set CASE_DIR to a writable runtime case directory containing etc/tmp/var/run}"
: "${GDB_CMDS:=$PWD/repro/gdb_capture_cmds.txt}"

mkdir -p "$CASE_DIR/tmp" "$CASE_DIR/etc" "$CASE_DIR/var/run"
rm -f "$CASE_DIR/tmp/.ripd"

exec unshare -Urnm sh -c '
set -eu
mount --bind '"$CASE_DIR"'/tmp /tmp
mount --bind '"$CASE_DIR"'/etc /etc
mount --bind '"$CASE_DIR"'/var/run /var/run
ip link set lo up
qemu-mipsel -g 1234 -L '"$ROOTFS"' '"$RIPD_BIN"' -f /etc/ripd.conf -P 2602 >/tmp/ripd-gdb-qemu.log 2>&1 &
QPID=$!
trap "kill $QPID 2>/dev/null || true" EXIT INT TERM
sleep 1
exec gdb-multiarch -q -x '"$GDB_CMDS"'
'
