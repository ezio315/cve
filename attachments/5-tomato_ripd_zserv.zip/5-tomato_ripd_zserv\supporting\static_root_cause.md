# Static Root Cause

Scope:

- vendor / product line: `Tomato by Shibby`
- verified version line: `Tomato v1.28.0005 124 ND USB`
- verified official package family:
  - `tomato-NDUSB-1.28.5x-124-Nocat-VPN.trx`
  - `tomato-NDUSB-1.28.5x-124-BT-VPN.trx`
- vulnerable binary: `usr/sbin/ripd`
- architecture: `MIPS32`

Primary vulnerable function:

- `rip_zebra_read_ipv4` at `0x40cad4`

Relevant receive chain:

- `zclient_start` connects to Unix socket `/tmp/.zserv`
- `zclient_read` parses old-style zserv frames with `len(2) + command(1)`
- `cmd=7` and `cmd=8` dispatch into `rip_zebra_read_ipv4`

Root cause:

1. `rip_zebra_read_ipv4` reads a one-byte `plen`.
2. It computes `copy_len = ((plen + 7) >> 3)`.
3. It calls `stream_get(sp + 0x30, stream, copy_len)`.
4. The destination region at `sp + 0x30` has only about 8 safe bytes before saved registers start.
5. Neither `rip_zebra_read_ipv4` nor `stream_get` clamps `plen <= 32` or `copy_len <= 8`.
6. Because an IPv4 prefix length above `32` should already be rejected on semantic grounds, the absence of that validation directly enables the oversized stack copy.

Important offsets:

- copy sink: `sp + 0x30`
- saved registers start: `sp + 0x38`
- saved `ra`: `sp + 0x4c`

Static thresholds:

- `plen >= 65` starts overwriting saved registers
- `plen >= 225` reaches saved `ra`
- `plen >= 249` can fully cover the 4-byte saved `ra`

Variant note:

- the same `plen -> ((plen + 7) >> 3) -> stream_get(stack, ...)` pattern was observed in multiple extracted `ripd` variants from the same Tomato 124 branch
- this submission relies only on the two mapped NDUSB 124 package lines above; broader variant mapping is not required for the current conservative filing

Security meaning:

- this is a stack-based out-of-bounds write on the local zebra-to-ripd IPC boundary
- the best fitting classifications are `CWE-121` and `CWE-787`
- the static thresholds explain why `plen >= 225` can reach saved control data, which is later confirmed by the bundled runtime and GDB evidence
