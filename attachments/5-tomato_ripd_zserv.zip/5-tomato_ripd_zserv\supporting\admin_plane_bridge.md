# Administrative Control-Plane Bridge Note

This note records why the attack surface may be broader than a purely manual same-host root action, while still remaining narrower than a direct remote exploit claim.

## Verified local boundary

The primary validated trigger remains the local zebra-to-ripd Unix socket:

- `/tmp/.zserv`

The directly verified runtime evidence still supports:

- `local privileged / same-host IPC boundary`

## Additional static product-line evidence

Static product-line evidence shows that authenticated administrative interfaces can influence the same routing control plane.

1. Routing configuration UI

- `advanced-routing.asp` exposes routing-related settings such as:
  - `dr_lan_rx`
  - `dr_wan_rx`
  - `routes_static`
  - `dhcp_routes`
- the same page prepares service actions such as:
  - `routing-restart`
  - `wan-restart`

2. Authenticated management submission path

- Tomato management pages submit through authenticated administrative endpoints and include `_http_id` request handling in the product-line web management code.
- This means routing-related configuration changes are not passive UI artifacts; they are part of the authenticated management control plane.

3. Service-control and daemon lifecycle evidence

- `rc` on the verified product line exposes strings and templates consistent with:
  - `action_service`
  - `start_zebra`
  - `ripd`
  - `/etc/zebra.conf`
  - `/etc/ripd.conf`
  - `router rip`
  - `dr_lan_rx`
  - `dr_wan_rx`

Taken together, these observations support the following product-line bridge:

```text
authenticated admin UI
  -> routing-related form values
  -> service restart action
  -> rc-driven zebra/ripd config generation and restart
  -> local zebra/ripd IPC boundary (/tmp/.zserv)
```

4. Remote administrative exposure controls

- `admin-access.asp` exposes management-related settings such as:
  - `remote_management`
  - `remote_mgt_https`
  - `sshd_remote`
  - `telnetd_eas`

This does not prove that the overflow itself is remotely reachable. It does show that, in deployments where remote administrative access is enabled, an authenticated administrator may be able to reach the same routing control plane from a remote management surface.

## Conservative conclusion

The present evidence supports the following cautious wording:

- primary validated claim: `local privileged / same-host IPC boundary`
- secondary static note: authenticated administrative interfaces appear able to indirectly influence the same zebra/ripd control plane, and this may extend to authenticated remote administration when remote management is enabled

The current evidence does **not** support:

- unauthenticated remote reachability
- direct remote access to `/tmp/.zserv`
- low-privilege local reachability
- default exposure without administrative enablement

## Why this note matters

This note should be used to explain that the validated overflow is not merely an artificial lab-only root action. The product line contains a real administrative bridge into the same routing service stack, even though the exact end-to-end path from authenticated remote admin to the verified overflow has not yet been dynamically reproduced on the verified sample.
