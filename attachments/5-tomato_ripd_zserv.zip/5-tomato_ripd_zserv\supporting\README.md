# Supporting Evidence Index

This directory contains the supporting evidence cited by `../report.md`.

Included files:

- `static_root_cause.md`
  - static receive path, stack layout, and overwrite thresholds
- `dynamic_verified.md`
  - runtime validation summary, PoC frame shape, crash observations, and conservative attack-surface note
- `gdb_capture_plen255.txt`
  - raw before/after stack capture at the vulnerable `stream_get` site with `plen=255`
- `runtime_socket_mode.txt`
  - socket ownership and mode capture showing `/tmp/.zserv` as root-owned `0700` in the validation environment
- `admin_plane_bridge.md`
  - static bridge note showing how authenticated administrative interfaces can indirectly influence the same routing control plane

Evidence roles:

- static proof: `static_root_cause.md`
- dynamic proof: `dynamic_verified.md`
- direct overwrite transcript: `gdb_capture_plen255.txt`
- attack-surface support: `runtime_socket_mode.txt`
- management-plane bridge support: `admin_plane_bridge.md`
