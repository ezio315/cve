# Tomato 固件的 www/apcupsd/tomatoups.cgi 组件存在栈溢出漏洞

## 1. 漏洞标题

`Tomato` 固件的 `www/apcupsd/tomatoups.cgi` 组件存在栈溢出漏洞

## 2. 基本信息

- 提交类型建议：`通用型 / 白盒固件逆向 + QEMU 动态验证`
- 厂商/产品：`Tomato` 固件（样本路径显示为 `tomato/...`）
- 受影响组件：`www/apcupsd/tomatoups.cgi`
- 已验证受影响样本：
  - 固件包样本 hash：`9ad48d5b61db7b4296578c7df6b7c09924d5290d`
  - 二进制 sha256：`dd976f1876f04688143558a6a7a08abf71e0b74fb8c55e8948c4a158bac0e6c7`
  - 架构：`ARM`
  - 解释器：`/lib/ld-uClibc.so.0`
  - 已验证路径：`target_binaries/tomato/9ad48d5b61db7b4296578c7df6b7c09924d5290d/www/apcupsd/tomatoups.cgi`
- 受影响版本说明：
  - 当前工作区可稳定指认的是与上述固件包 hash 对应的样本
  - 样本内未直接提取到足够可靠的公开版本号字符串
  - 建议厂商依据该固件包 hash 反向映射具体发布版本并扩展排查
- 漏洞类型：
  - 栈溢出
  - 越界写
- CWE：
  - `CWE-121` Stack-based Buffer Overflow
  - `CWE-787` Out-of-bounds Write
  - `CWE-120` Classic Buffer Overflow
- 风险等级建议：`高危`

## 3. 漏洞描述

`tomatoups.cgi` 会通过 TCP `3551` 从 UPS 服务获取文本协议字段，然后在页面渲染阶段调用 `sub_9068(host, field, buf, len)` 提取具体字段值。  

问题在于，`sub_9068` 内存在两条危险写入路径：

- `0x914c`：`sscanf("%*s %*s %s", a3)`，对目标缓冲区 `a3` 没有宽度限制
- `0x90ec`：按字节复制直到 `'\n'`，未比较调用方传入的长度参数 `a4`

其中 `sub_97E0` 的 `upstemp` 路径会以固定上限 `0x40`（64 字节）调用：

- `0x97f8`：`sub_9068(a1, "upstemp", v2, 0x40)`

而 `v2` 是该函数栈上的 64 字节局部缓冲区。一旦攻击者可控 UPS 侧 `ITEMP` 字段返回 64 字节及以上的值，`%s` 路径会在写满 64 字节后继续写入终止 NUL，从而破坏紧邻缓冲区后的保存寄存器/返回现场，最终导致进程崩溃。

这不是仅凭静态分析得出的推测，本样本已经通过匹配 rootfs 下的 `QEMU + GDB` 动态验证，完整抓到了：

1. `sub_97E0(..., 0x40)` 调用现场
2. `ITEMP` 数据进入 `%s` sink
3. 缓冲区后第一个字节被终止 NUL 改写
4. 随后的目标侧 `SIGSEGV`

## 4. 漏洞根因

根因是字段提取函数 `sub_9068` 在处理来自 UPS 响应的文本协议数据时，忽略了调用方给定的缓冲区长度约束：

- 调用方确实传入了 `a4=0x40`
- 但 `%s` 分支没有把该上限带入格式串
- 逐字节复制分支也未在循环中做边界比较
- 因而攻击者控制的字段值长度直接决定实际写入长度

对于本次已验证的 `upstemp` 路径，危险调用链为：

`UPS 响应 -> sub_A754 -> sub_8D18 -> sub_9068 -> 0x914c sscanf("%*s %*s %s", a3) -> sub_97E0 栈缓冲区`

## 5. 触发条件与攻击场景

触发前提如下：

- 设备启用了 `apcupsd` 对应 CGI 页面
- 攻击者可以控制、仿冒，或中间人篡改被查询的 UPS 服务响应
- 目标通过 CGI 页面触发对 UPS 服务的查询
- 攻击者返回的 `ITEMP` 字段值长度 `>= 64`

本次动态验证使用的最小触发条件为：

- `QUERY_STRING="host=127.0.0.1&refresh=1"`
- `/usr/local/apcupsd/multimon.conf` 被最小化为仅保留 `FIELD UPSTEMP "UPS Temp" ""`
- 恶意 UPS 返回：
  - `DATE` 为 16 字节
  - `ITEMP` 为 64 个 `A`

在该条件下，即使攻击者只提供 **恰好 64 个字节**，`sscanf()` 写入目标缓冲区后附带的终止 NUL 也会成为第 65 个字节，从而越过 64 字节边界并改写后续栈数据。

## 6. 动态验证结果

本漏洞已在匹配 rootfs 下通过 `qemu-arm` 与 `gdb-multiarch` 动态验证为真实栈越界写，并已观察到崩溃。

### 6.1 运行时恢复情况

- 匹配 rootfs：
  - `/home/kali/Desktop/firmware-CNVD/_firmware_runtime/unpacked/tomato/9ad48d5b61db7b4296578c7df6b7c09924d5290d.trx`
- 运行目标：
  - `.../trx/www/apcupsd/tomatoups.cgi`
- 通过 `bwrap` 将 `/usr/local/apcupsd` 映射到 case 专用最小配置目录：
  - `_firmware_runtime_cases/D-001/apcupsd_min_upstemp`
- 使用自定义 fake UPS：
  - `d001_multi_field_server.py --host 127.0.0.1 --port 3551 --date-pad 16 --pad 64 --max-clients 2`

### 6.2 关键动态证据

- `0x97f8`：已抓到 `r0="127.0.0.1"`、`r1="upstemp"`、`r2=<stack buf>`、`r3=0x40`
- `0x914c`：已抓到源串 `ITEMP    : AAAAA...`，值部分恰为 64 个 `A`
- `0x9150` 之后：
  - `buf[0..63]` 全部为 `0x41`
  - `buf+0x40` 的首字节从 `0x78` 变成 `0x00`
  - 保存的 `r4` 从 `0x00017278` 变为 `0x00017200`
- 纯 `QEMU` 运行同步出现：
  - `qemu: uncaught target signal 11 (Segmentation fault) - core dumped`
- `GDB` 续跑时也捕获到：
  - `Program received signal SIGSEGV`
  - 崩溃位置：`strcmp()` in target `libc.so.0`

这些证据表明：攻击者输入不仅进入了危险 sink，而且已经实际越过 64 字节边界、破坏调用栈，并导致目标崩溃。

### 6.3 证据截图

图 1：`0x97f8` 命中时，`upstemp` 的 `0x40` 栈缓冲区路径已被真实触发。

![Figure 1 - 0x97f8 UPSTEMP call site](d001_fig_01_upstemp_callsite.png)

图 2：`0x914c` 处可以看到 `ITEMP` 恶意值进入 `%s` sink，且调用上限仍为 `0x40`。

![Figure 2 - 0x914c sscanf sink](d001_fig_02_upstemp_sink.png)

图 3：`0x9150` 之后，64 字节局部栈缓冲区被写满，后续保存寄存器槽位发生变化，说明已经形成边界外写入。

![Figure 3 - stack overwrite after sscanf](d001_fig_03_stack_overwrite.png)

图 4：目标最终在运行时收到 `SIGSEGV`，plain QEMU 与 GDB 路径均能复现。

![Figure 4 - crash after the overwrite](d001_fig_04_sigsegv.png)

## 7. 影响评估

若攻击者可以控制或劫持设备访问的 UPS 服务返回内容，则可利用该问题：

- 向 64 字节栈缓冲区写入超界数据
- 破坏保存寄存器或返回现场
- 触发 CGI 进程崩溃，导致拒绝服务
- 在更有利的栈布局或编译条件下，进一步争取控制流劫持

由于该漏洞存在于真实固件 CGI 组件中，且已通过动态验证确认能够造成栈破坏与 `SIGSEGV`，风险建议为 `高危`。

## 8. 修复建议

- 对 `sub_9068` 的 `%s` 分支改为带宽度限制的格式串，且宽度必须与 `a4-1` 绑定
- 对逐字节复制分支在循环中加入显式边界检查
- 对所有 `sub_9068(..., <field>, buf, len)` 调用点统一复查，避免仅修补单一路径
- 对从网络协议解析到 CGI 输出的整条链增加长度校验
- 审计同一固件中的 `multimon.cgi`、`tomatodata.cgi` 等同类 `apcupsd` CGI，确认是否存在同根因问题

## 9. 复现摘要

本次可复现实验的最小思路为：

1. 使用匹配 rootfs 启动 `qemu-arm`
2. 用 `bwrap` 将 `/usr/local/apcupsd` 指向 case 专用最小配置
3. 启动 fake UPS，返回 64 字节 `ITEMP`
4. 触发 `QUERY_STRING="host=127.0.0.1&refresh=1"`
5. 观察：
   - `0x97f8` 处 `r3=0x40`
   - `0x914c` 处命中 `%s` sink
   - `0x9150` 后 `buf+0x40` 被改写
   - 进程收到 `SIGSEGV`

## 10. 建议的简短描述

`Tomato` 固件的 `www/apcupsd/tomatoups.cgi` 在处理 UPS 文本协议字段时，对 `sub_9068(..., "upstemp", buf, 0x40)` 的 `%s` 写入路径缺少长度限制。攻击者只需让 `ITEMP` 字段值达到 64 字节，即可触发 64 字节栈缓冲区后的 1-byte 越界写，并在运行时造成目标侧 `SIGSEGV`；该问题已通过 QEMU 与 GDB 动态验证。

