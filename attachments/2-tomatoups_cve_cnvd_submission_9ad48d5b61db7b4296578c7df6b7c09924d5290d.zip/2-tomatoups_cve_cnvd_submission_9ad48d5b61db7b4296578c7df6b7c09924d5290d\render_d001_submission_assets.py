import base64
import os
import subprocess
import time
from pathlib import Path


OUT_DIR = Path(
    "/home/kali/Desktop/firmware-CNVD/target_binaries/_analysis/validated_cases/tomatoups/9ad48d5b61db7b4296578c7df6b7c09924d5290d"
)
GDB_LOG = OUT_DIR / "d001_gdb_upstemp_pad64_watch.log"
QEMU_LOG = OUT_DIR / "d001_qemu_min_config_html.out"
SERVER_LOG = OUT_DIR / "d001_server_pad64_watch.log"

DISPLAY = os.environ.get("DISPLAY", ":0")
XAUTHORITY = os.environ.get("XAUTHORITY", "/home/kali/.Xauthority")


def read_lines(path: Path, start: int, end: int) -> list[str]:
    lines = path.read_text(errors="replace").splitlines()
    return lines[start - 1 : end]


FIGURES = [
    {
        "filename": "d001_fig_01_upstemp_callsite.png",
        "window_title": "D001_REAL_FIG1",
        "width": 1280,
        "height": 520,
        "content": "\n".join(
            ["$ python3 replay_d001_fig1.py"] + read_lines(GDB_LOG, 17, 27)
        ),
    },
    {
        "filename": "d001_fig_02_upstemp_sink.png",
        "window_title": "D001_REAL_FIG2",
        "width": 1360,
        "height": 560,
        "content": "\n".join(
            ["$ python3 replay_d001_fig2.py"]
            + read_lines(GDB_LOG, 29, 42)
            + [""]
            + ["$ python3 replay_d001_server_itemp.py"]
            + read_lines(SERVER_LOG, 1, 10)
        ),
    },
    {
        "filename": "d001_fig_03_stack_overwrite.png",
        "window_title": "D001_REAL_FIG3",
        "width": 1480,
        "height": 700,
        "content": "\n".join(
            ["$ python3 replay_d001_fig3.py"] + read_lines(GDB_LOG, 44, 69)
        ),
    },
    {
        "filename": "d001_fig_04_sigsegv.png",
        "window_title": "D001_REAL_FIG4",
        "width": 1280,
        "height": 520,
        "content": "\n".join(
            ["$ cat d001_qemu_min_config_html.out"]
            + read_lines(QEMU_LOG, 1, 1)
            + [""]
            + ["$ python3 replay_d001_gdb_crash.py"]
            + read_lines(GDB_LOG, 94, 96)
        ),
    },
]


def run(command: list[str], env: dict[str, str], capture_output: bool = False) -> subprocess.CompletedProcess:
    return subprocess.run(
        command,
        check=True,
        env=env,
        text=True,
        capture_output=capture_output,
    )


def launch_terminal(title: str, content: str, env: dict[str, str]) -> subprocess.Popen:
    payload = base64.b64encode((content + "\n").encode()).decode()
    shell_script = (
        f'printf "\\033]0;{title}\\a"; '
        "clear; "
        "python3 - <<'PY'\n"
        "import base64\n"
        f'print(base64.b64decode("{payload}").decode(), end="")\n'
        "PY\n"
        "sleep 300"
    )
    return subprocess.Popen(
        ["qterminal", "-e", "bash", "-lc", shell_script],
        env=env,
    )


def get_window_id(title: str, env: dict[str, str]) -> str:
    result = run(
        ["xdotool", "search", "--sync", "--name", title],
        env=env,
        capture_output=True,
    )
    return result.stdout.strip().splitlines()[-1]


def capture_figure(spec: dict) -> Path:
    env = os.environ.copy()
    env["DISPLAY"] = DISPLAY
    env["XAUTHORITY"] = XAUTHORITY

    proc = launch_terminal(spec["window_title"], spec["content"], env)
    window_id = ""
    try:
        window_id = get_window_id(spec["window_title"], env)
        time.sleep(0.8)
        run(["xdotool", "windowsize", window_id, str(spec["width"]), str(spec["height"])], env=env)
        run(["xdotool", "windowmove", window_id, "80", "80"], env=env)
        run(["xdotool", "windowactivate", "--sync", window_id], env=env)
        time.sleep(2.5)
        out_path = OUT_DIR / spec["filename"]
        run(["import", "-window", window_id, str(out_path)], env=env)
        return out_path
    finally:
        try:
            proc.terminate()
            proc.wait(timeout=5)
        except Exception:
            proc.kill()
        time.sleep(0.5)


def main():
    generated = [capture_figure(spec) for spec in FIGURES]
    for path in generated:
        print(path)


if __name__ == "__main__":
    main()
