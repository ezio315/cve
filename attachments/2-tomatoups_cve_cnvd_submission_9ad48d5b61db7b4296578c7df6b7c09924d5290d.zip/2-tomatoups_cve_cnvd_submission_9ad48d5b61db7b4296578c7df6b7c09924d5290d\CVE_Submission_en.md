# CVE Submission Draft: Stack-Based Off-by-One Overwrite in `apcupsd/tomatoups.cgi`

## 1. Proposed Title

Stack-based off-by-one overwrite in `www/apcupsd/tomatoups.cgi` in `Tomato` firmware

## 2. Affected Product

- Vendor / product family: `Tomato` firmware
- Affected component: `www/apcupsd/tomatoups.cgi`
- Verified affected sample:
  - firmware package hash: `9ad48d5b61db7b4296578c7df6b7c09924d5290d`
  - binary sha256: `dd976f1876f04688143558a6a7a08abf71e0b74fb8c55e8948c4a158bac0e6c7`
  - architecture: `ARM`
  - interpreter: `/lib/ld-uClibc.so.0`
  - verified path: `target_binaries/tomato/9ad48d5b61db7b4296578c7df6b7c09924d5290d/www/apcupsd/tomatoups.cgi`
- Affected version note:
  - the currently available sample set does not expose a stable public release string
  - at minimum, the release corresponding to the verified firmware package hash above is affected
  - the vendor should map the package hash back to exact public release identifiers and assess neighboring releases

## 3. Vulnerability Type

- Stack-based buffer overflow
- Out-of-bounds write
- Off-by-one stack overwrite
- CWE:
  - `CWE-121` Stack-based Buffer Overflow
  - `CWE-787` Out-of-bounds Write
  - `CWE-193` Off-by-one Error
- Suggested severity: `High`

## 4. Vulnerability Description

`tomatoups.cgi` queries a UPS service over TCP port `3551` and parses text protocol fields through `sub_9068(host, field, buf, len)`.

Inside `sub_9068`, two unsafe write paths exist:

- `0x914c`: `sscanf("%*s %*s %s", a3)` with no width limit for the destination buffer
- `0x90ec`: byte-by-byte copy until `'\n'` without enforcing the caller-supplied length limit

The verified runtime path in this case is the `upstemp` handler:

- `0x97f8`: `sub_9068(a1, "upstemp", v2, 0x40)`

Here, `v2` is a 64-byte stack buffer local to `sub_97E0`. When the attacker-controlled UPS response provides an `ITEMP` value of 64 bytes, the `%s` conversion fills the entire local buffer with attacker data and then writes the terminating NUL byte as the 65th byte, immediately corrupting saved stack data placed after the buffer.

This is not just a theoretical condition. The path has been dynamically verified under QEMU with GDB, including:

1. the exact `sub_97E0(..., 0x40)` call site
2. attacker-controlled `ITEMP` input entering the `%s` sink
3. the byte directly past the 64-byte buffer changing on the stack
4. a subsequent target-side `SIGSEGV`

## 5. Root Cause

The root cause is that `sub_9068` ignores the effective destination length supplied by the caller:

- the caller correctly passes `a4=0x40`
- the `%s` branch does not bind that limit into the format string
- the byte-copy branch also omits a runtime boundary check
- therefore, attacker-controlled field length determines the actual number of bytes written

For the verified `upstemp` case, the dangerous chain is:

`UPS response -> sub_A754 -> sub_8D18 -> sub_9068 -> 0x914c sscanf("%*s %*s %s", a3) -> stack buffer in sub_97E0`

## 6. Attack Scenario / Preconditions

The issue becomes reachable when:

- the device exposes the `apcupsd` CGI page
- the attacker can control, emulate, or tamper with the queried UPS service response
- the CGI path queries the UPS host
- the attacker returns an `ITEMP` value with length `>= 64`

The minimal verified trigger used in the lab was:

- `QUERY_STRING="host=127.0.0.1&refresh=1"`
- a reduced `multimon.conf` containing only:
  - `FIELD UPSTEMP "UPS Temp" ""`
- malicious UPS response values:
  - `DATE`: 16 bytes
  - `ITEMP`: 64 bytes of `A`

Even with exactly 64 controlled bytes, the trailing NUL written by `sscanf()` becomes the 65th byte and corrupts the first byte immediately beyond the intended 64-byte buffer.

## 7. Runtime Verification

The issue was runtime-verified with a matching extracted rootfs using `qemu-arm` and `gdb-multiarch`.

### 7.1 Runtime bring-up

- matching rootfs:
  - `/home/kali/Desktop/firmware-CNVD/_firmware_runtime/unpacked/tomato/9ad48d5b61db7b4296578c7df6b7c09924d5290d.trx`
- target binary:
  - `.../trx/www/apcupsd/tomatoups.cgi`
- `/usr/local/apcupsd` was redirected via `bwrap` to a case-specific minimal configuration directory
- fake UPS server used:
  - `d001_multi_field_server.py --host 127.0.0.1 --port 3551 --date-pad 16 --pad 64 --max-clients 2`

### 7.2 Key runtime evidence

- at `0x97f8`, GDB recorded:
  - `r0="127.0.0.1"`
  - `r1="upstemp"`
  - `r2=<stack buffer>`
  - `r3=0x40`
- at `0x914c`, GDB recorded:
  - source string: `ITEMP    : A...`
  - attacker-controlled value length: exactly 64 bytes
  - active sink: `sscanf("%*s %*s %s", a3)`
- immediately after `0x9150`:
  - `buf[0..63]` is entirely `0x41`
  - the byte at `buf+0x40` changed from `0x78` to `0x00`
  - saved stack data changed from `0x00017278` to `0x00017200`
- plain QEMU reproduction also crashed with:
  - `qemu: uncaught target signal 11 (Segmentation fault) - core dumped`
- the GDB-assisted run then stopped on:
  - `Program received signal SIGSEGV`
  - crash site: `strcmp()` in target `libc.so.0`

This proves a real stack out-of-bounds write followed by a runtime crash, not merely a syntactic or static-analysis issue.

### 7.3 Breakpoint images

`0x97f8` shows entry into the 64-byte `upstemp` stack-buffer path:

![Figure 1 - 0x97f8 UPSTEMP call site](d001_fig_01_upstemp_callsite.png)

`0x914c` shows the attacker-controlled `ITEMP` line reaching the `%s` sink:

![Figure 2 - 0x914c sscanf sink](d001_fig_02_upstemp_sink.png)

`0x9150` shows the stack buffer fully filled and the byte beyond the boundary changed:

![Figure 3 - stack overwrite after sscanf](d001_fig_03_stack_overwrite.png)

The process then crashes with a real target-side segmentation fault:

![Figure 4 - crash after the overwrite](d001_fig_04_sigsegv.png)

## 8. Security Impact

If an attacker can control or tamper with the UPS service response consumed by the CGI component, the issue can enable:

- stack corruption in a real firmware CGI process
- denial of service through process crash
- corruption of saved register / return-adjacent stack data
- possible control-flow exploitation under more favorable stack layouts or mitigation settings

Because the flaw is present in production firmware logic and has already been shown to corrupt the stack and end in `SIGSEGV`, a `High` severity assessment is recommended.

## 9. Reproduction Summary

The attached helper files implement a reproducible lab flow:

1. boot the matching userspace under `qemu-arm`
2. redirect `/usr/local/apcupsd` to the minimal case configuration
3. start the fake UPS server and return a 64-byte `ITEMP`
4. trigger the CGI with `QUERY_STRING="host=127.0.0.1&refresh=1"`
5. observe:
   - `0x97f8` with `r3=0x40`
   - `0x914c` on the `%s` sink
   - `0x9150` with stack data changed at `buf+0x40`
   - final `SIGSEGV`

## 10. Suggested Short CVE Description

A stack-based off-by-one overflow exists in `www/apcupsd/tomatoups.cgi` in `Tomato` firmware because `sub_9068(..., "upstemp", buf, 0x40)` uses `sscanf("%*s %*s %s", buf)` without a width limit. An attacker-controlled `ITEMP` value of 64 bytes is sufficient to fill the 64-byte stack buffer and write the terminating NUL one byte past the boundary, corrupting saved stack data and causing a target-side `SIGSEGV`.

## 11. Supporting Files

- Chinese submission draft: `CNVD_Submission_zh.md`
- Chinese submission docx: `CNVD_Submission_zh.docx`
- English submission draft: `CVE_Submission_en.md`
- dynamic verification summary: `d001_dynamic_verified_upstemp_pad64.md`
- key GDB log: `d001_gdb_upstemp_pad64_watch.log`
- plain QEMU crash output: `d001_qemu_min_config_html.out`
- fake UPS interaction log: `d001_server_pad64_watch.log`
- breakpoint / evidence images:
  - `d001_fig_01_upstemp_callsite.png`
  - `d001_fig_02_upstemp_sink.png`
  - `d001_fig_03_stack_overwrite.png`
  - `d001_fig_04_sigsegv.png`
- helper files:
  - `d001_multi_field_server.py`
  - `d001_gdb_upstemp_pad64_watch.gdb`
  - `d001_apcupsd_min_upstemp_multimon.conf`
  - `render_d001_submission_assets.py`

## 12. Note

- This draft is suitable as a white-box firmware-analysis supporting document for CNA / CVE review.
- The most reliable verified path is the single-column `UPSTEMP` lab configuration included in the attachment set.
- Related CGI components in the same workspace (`tomatodata.cgi`, `multimon.cgi`) were also verified as vulnerable in separate analyses, which may help the vendor assess code reuse and broader impact.
