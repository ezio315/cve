set pagination off
set confirm off
set architecture arm
set auto-solib-add off
set breakpoint always-inserted on
handle SIGSEGV stop print
set $watch_upstemp = 0
set $buf = 0
target remote :1236

break *0x97f8
commands
silent
printf "\n[BP 0x97f8] upstemp call site\n"
info registers r0 r1 r2 r3 sp lr pc
x/s $r0
x/s $r1
set $watch_upstemp = 1
set $buf = $r2
x/4wx $buf+0x40
continue
end

break *0x914c if $watch_upstemp
commands
silent
printf "\n[BP 0x914c] upstemp sscanf sink\n"
info registers r0 r1 r2 r3 r4 r5 r6 r7 sp lr pc
x/s $r0
x/s $r1
set $buf = $r2
continue
end

break *0x9150 if $watch_upstemp
commands
silent
printf "\n[BP 0x9150] upstemp after sscanf\n"
info registers r0 r1 r2 r3 r4 r5 r6 r7 sp lr pc
x/96bx $buf
x/8wx $buf+0x40
continue
end

break *0x8dfc if $watch_upstemp
commands
silent
printf "\n[BP 0x8dfc] upstemp failure cleanup\n"
info registers r0 r1 r2 r3 sp lr pc
continue
end

break *0x97fc
commands
silent
printf "\n[BP 0x97fc] upstemp return site\n"
info registers r0 r1 r2 r3 sp lr pc
x/96bx $sp
x/8wx $sp+0x40
set $watch_upstemp = 0
continue
end

continue
