# `tomatoups.cgi` CVE/CNVD 提交材料包

本目录包含当前 `tomatoups.cgi` 已验证漏洞的对外提交材料与关键证据。

## 1. 提交稿

- `CNVD_Submission_zh.md`
- `CVE_Submission_en.md`

后续已同步转换为：

- `CNVD_Submission_zh.docx`
- `CVE_Submission_en.docx`

## 2. 关键证据

- 动态验证摘要：
  - `d001_dynamic_verified_upstemp_pad64.md`
- 截图：
  - `d001_fig_01_upstemp_callsite.png`
  - `d001_fig_02_upstemp_sink.png`
  - `d001_fig_03_stack_overwrite.png`
  - `d001_fig_04_sigsegv.png`
- 关键日志：
  - `d001_gdb_upstemp_pad64_watch.log`
  - `d001_qemu_min_config_html.out`
  - `d001_server_pad64_watch.log`
- 复现辅助文件：
  - `d001_multi_field_server.py`
  - `d001_gdb_upstemp_pad64_watch.gdb`
  - `d001_apcupsd_min_upstemp_multimon.conf`
  - `render_d001_submission_assets.py`

## 3. 当前结论

- 漏洞状态：`verified`
- 核心结论：
  - `sub_97E0 -> sub_9068(..., "upstemp", buf, 0x40) -> 0x914c`
  - 64 字节 `ITEMP` 值可填满 64 字节局部栈缓冲区
  - 终止 NUL 继续写到 `buf+0x40`，形成 1-byte 栈越界写
  - 随后目标侧收到 `SIGSEGV`
- 风险建议：`高危`

## 4. 提交注意事项

- 中文稿适合 `CNVD` 白盒 / 通用型提交
- 英文稿适合 `CVE/CNA` 技术支撑材料
- 当前样本未直接恢复出稳定的公开版本号，提交时“受影响版本”字段建议写为：
  - 至少包含与样本 hash `9ad48d5b61db7b4296578c7df6b7c09924d5290d` 对应的发布版本
  - 建议厂商据固件包 hash 回溯精确公开版本并扩展排查
- 正式对外提交前仍建议做一次编号去重检查

## 5. 打包文件

已另外生成压缩包：

- `tomatoups_cve_cnvd_submission_9ad48d5b61db7b4296578c7df6b7c09924d5290d.zip`
