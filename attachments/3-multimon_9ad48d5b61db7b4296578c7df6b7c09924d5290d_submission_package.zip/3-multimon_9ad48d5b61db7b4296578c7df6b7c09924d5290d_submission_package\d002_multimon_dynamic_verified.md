# D-002 multimon.cgi Dynamic Validation

- conclusion: `verified`
- binary(source): `/home/kali/Desktop/firmware-CNVD/target_binaries/tomato/9ad48d5b61db7b4296578c7df6b7c09924d5290d/www/apcupsd/multimon.cgi`
- binary(runtime): `/home/kali/Desktop/firmware-CNVD/_firmware_runtime/unpacked/tomato/9ad48d5b61db7b4296578c7df6b7c09924d5290d.trx/www/apcupsd/multimon.cgi`
- rootfs: `/home/kali/Desktop/firmware-CNVD/_firmware_runtime/unpacked/tomato/9ad48d5b61db7b4296578c7df6b7c09924d5290d.trx`
- query-string: `host=127.0.0.1&refresh=1`

## Runtime & Architecture Check

- `file/readelf` confirms ARM ELF with interpreter `/lib/ld-uClibc.so.0`.
- Dynamic execution used `qemu-arm` under `bwrap` to map `/usr/local/apcupsd` to rootfs config.

## Breakpoint Evidence

- `0x9174` hit count: `1` (captured first OOB write condition).
- `0x918c` hit count: `1` (copy completed with overlong length).
- `0x91d4` hit count: `4` (`sscanf("%*s %*s %s")` sink reached).
- `0x98b0` hit count: `1` (`a4=0x40` call-path breakpoint reached).
- `0xa24c` hit count: `1` (`date` path breakpoint reached).

Key registers from `0x9174` / `0x918c`:

- At `0x9174`: `r6=0x100`, `r7=0x100` (first write at boundary).
- At `0x918c`: `r7=0x2bc` (700 bytes copied), with `0x41` observed beyond `+0x100`.

## Crash Evidence

- GDB captured `SIGSEGV` with PC at `0x41414140`, showing attacker-controlled pattern in control flow.
- Fake server request body captured as `status` and payload sent successfully.

## Artifacts

- raw json: `/home/kali/Desktop/firmware-CNVD/target_binaries/_analysis/validated_cases/multimon/9ad48d5b61db7b4296578c7df6b7c09924d5290d/d002_multimon_dynamic_verified.json`
- gdb transcript: `/home/kali/Desktop/firmware-CNVD/target_binaries/_analysis/validated_cases/multimon/9ad48d5b61db7b4296578c7df6b7c09924d5290d/d002_gdb_capture.txt`
- gdb snapshot png: `/home/kali/Desktop/firmware-CNVD/target_binaries/_analysis/validated_cases/multimon/9ad48d5b61db7b4296578c7df6b7c09924d5290d/d002_gdb_evidence.png`
- qemu stdout/stderr: `/home/kali/Desktop/firmware-CNVD/target_binaries/_analysis/validated_cases/multimon/9ad48d5b61db7b4296578c7df6b7c09924d5290d/d002_qemu_stdout.log`, `/home/kali/Desktop/firmware-CNVD/target_binaries/_analysis/validated_cases/multimon/9ad48d5b61db7b4296578c7df6b7c09924d5290d/d002_qemu_stderr.log`

## Blocker

- `None`
