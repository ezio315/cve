# Tomato by Shibby multimon.cgi 栈溢出漏洞

## 1. 漏洞标题

`Tomato by Shibby` 固件 `www/apcupsd/multimon.cgi` 组件存在栈溢出漏洞

## 2. 基本信息

- 厂商/产品：`Tomato by Shibby`
- 受影响组件：`www/apcupsd/multimon.cgi`
- 已验证受影响样本：
  - hash：`9ad48d5b61db7b4296578c7df6b7c09924d5290d`
  - 架构：`ARM`
  - 二进制 sha256：`68dac0594a1d9412aa48e01d6ea8dc843dc04f067eb3dbc7f1670e20d3f6ef50`
- 漏洞类型：栈溢出 / 越界写
- CWE：
  - `CWE-121` Stack-based Buffer Overflow
  - `CWE-787` Out-of-bounds Write
- 风险等级建议：高危

## 3. 漏洞描述

`multimon.cgi` 在生成 UPS 监控页面时，会读取 `usr/local/apcupsd/hosts.conf` 中配置的监控目标，向 UPS 服务发送 `status` 请求，并解析返回的文本字段到调用方提供的栈缓冲区中。

经验证，危险辅助函数 `sub_90F0` 同时存在两条无边界写入路径：

- `0x9174`：按换行符结束的逐字节复制循环，未校验调用方传入的长度上限
- `0x91d4`：`sscanf("%*s %*s %s", a3)`，其中 `%s` 未设置宽度限制

典型调用点包括：

- `0x98b0`：`sub_90F0(..., "upstemp", ..., 0x40)`
- `0xa24c`：`sub_90F0(..., "date", ..., 0x100)`

因此，当攻击者可控 UPS 返回字段长度超过调用方缓冲区上限时，会发生越界写，覆盖栈上相邻数据，形成栈溢出。

## 4. 漏洞根因

根因是 `sub_90F0` 在处理攻击者可控 UPS 返回字段时，没有对写入目标缓冲区执行有效边界检查：

- 调用方明确传入了有限长度，如 `0x40` 或 `0x100`
- 解析逻辑从 UPS 返回中选取指定字段
- 一条路径持续复制直到 `\\n`
- 另一条路径通过 `%s` 读取任意长 token
- 两条路径都没有严格遵守调用方提供的缓冲区大小

## 5. 触发条件与攻击场景

- 设备运行 `multimon.cgi`
- 页面访问触发程序读取 `hosts.conf` 中的 `MONITOR` 主机
- 程序向目标 UPS 服务发送请求体 `status`
- 攻击者能够控制该 UPS 服务，或在网络路径上伪造/替换其响应
- 攻击者返回超长字段值，例如 `DATE`、`ITEMP`、`LINEV`、`MINLINEV`、`MAXLINEV`

在上述条件下，页面渲染过程中即可触发越界写。

## 6. 动态验证结果

本漏洞已在匹配 rootfs 下通过 `qemu-arm` 与 `gdb-multiarch` 动态验证。

已确认事实：

- `file/readelf` 实测该样本为 `ARM`，解释器为 `/lib/ld-uClibc.so.0`
- Fake UPS 服务成功收到请求体 `status`
- `0xa24c` 断点命中，证明 `date` 路径被执行，调用上限为 `0x100`
- `0x98b0` 断点命中，证明 `0x40` 缓冲区路径也被执行
- `0x9174` 断点命中时：
  - `r6 = 0x100`
  - `r7 = 0x100`
  - 表明写入已经到达调用方声明的边界
- `0x918c` 断点命中时：
  - `r7 = 0x2bc`
  - 即总共复制了 700 字节
  - `dest + 0x100` 之后仍连续出现攻击者可控的 `0x41`
- `0x91d4` 的 `sscanf("%*s %*s %s")` sink 命中 4 次
- 最终运行出现 `SIGSEGV`，PC = `0x41414140`，说明攻击者可控字节模式已进入控制流

## 7. 影响评估

该漏洞可能导致：

- CGI 进程崩溃，形成拒绝服务
- 栈上局部变量与相邻数据被破坏
- 保存寄存器或返回地址被覆盖
- 在特定条件下进一步劫持控制流

## 8. 修复建议

- 对 `sub_90F0` 的所有写入路径增加统一边界检查
- 禁止无宽度 `%s` 写入，改为显式长度限制
- 对逐字节复制逻辑引入剩余空间计数
- 当字段长度超过缓冲区大小时，应截断并返回错误
- 同时复核 `apcupsd` 相关兄弟 CGI 中是否复用了同类解析逻辑

## 9. 建议的简短描述

`Tomato by Shibby` 固件 `www/apcupsd/multimon.cgi` 在解析攻击者可控 UPS 返回字段时，未对固定大小栈缓冲区执行边界检查，导致栈溢出；该问题已在 ARM 样本中通过 QEMU 与 gdb 动态验证。

## 10. 原始动态验证

# D-002 multimon.cgi Dynamic Validation

- conclusion: `verified`
- binary(source): `/target_binaries/tomato/9ad48d5b61db7b4296578c7df6b7c09924d5290d/www/apcupsd/multimon.cgi`
- binary(runtime): `/unpacked/tomato/9ad48d5b61db7b4296578c7df6b7c09924d5290d.trx/www/apcupsd/multimon.cgi`
- rootfs: `/_firmware_runtime/unpacked/tomato/9ad48d5b61db7b4296578c7df6b7c09924d5290d.trx`
- query-string: `host=127.0.0.1&refresh=1`

### Runtime & Architecture Check

- `file/readelf` confirms ARM ELF with interpreter `/lib/ld-uClibc.so.0`.
- Dynamic execution used `qemu-arm` under `bwrap` to map `/usr/local/apcupsd` to rootfs config.

### Breakpoint Evidence

- `0x9174` hit count: `1` (captured first OOB write condition).
- `0x918c` hit count: `1` (copy completed with overlong length).
- `0x91d4` hit count: `4` (`sscanf("%*s %*s %s")` sink reached).
- `0x98b0` hit count: `1` (`a4=0x40` call-path breakpoint reached).
- `0xa24c` hit count: `1` (`date` path breakpoint reached).

Key registers from `0x9174` / `0x918c`:

- At `0x9174`: `r6=0x100`, `r7=0x100` (first write at boundary).
- At `0x918c`: `r7=0x2bc` (700 bytes copied), with `0x41` observed beyond `+0x100`.

### Crash Evidence

- GDB captured `SIGSEGV` with PC at `0x41414140`, showing attacker-controlled pattern in control flow.
- Fake server request body captured as `status` and payload sent successfully.

### Artifacts

- raw json: `/target_binaries/_analysis/validated_cases/multimon/9ad48d5b61db7b4296578c7df6b7c09924d5290d/d002_multimon_dynamic_verified.json`
- gdb transcript: `/target_binaries/_analysis/validated_cases/multimon/9ad48d5b61db7b4296578c7df6b7c09924d5290d/d002_gdb_capture.txt`
- gdb snapshot png: `/target_binaries/_analysis/validated_cases/multimon/9ad48d5b61db7b4296578c7df6b7c09924d5290d/d002_gdb_evidence.png`
- qemu stdout/stderr: `/target_binaries/_analysis/validated_cases/multimon/9ad48d5b61db7b4296578c7df6b7c09924d5290d/d002_qemu_stdout.log`, `/target_binaries/_analysis/validated_cases/multimon/9ad48d5b61db7b4296578c7df6b7c09924d5290d/d002_qemu_stderr.log`

### Blocker

- `None`

## 11. gdb动态调试记录

```
Reading /lib/ld-uClibc.so.0 from remote target...
warning: File transfers from remote targets can be slow. Use "set sysroot" to access files locally instead.
Reading /lib/ld-uClibc.so.0 from remote target...
0x40808930 in _start () from target:/lib/ld-uClibc.so.0
Breakpoint 1 at 0x9860
Breakpoint 2 at 0x98b0
Breakpoint 3 at 0xa24c
Breakpoint 4 at 0x91d4
Breakpoint 5 at 0x9174
Breakpoint 6 at 0x918c
Reading /lib/libc.so.0 from remote target...

[BP_0x9174_oob_write_condition]
r0             0x14c60             85088
r1             0xbcc8              48328
r2             0x41                65
r3             0x14d6b             85355
r4             0xbcbc              48316
r5             0x407ffb58          1082129240
r6             0x100               256
r7             0x100               256
r8             0xba80              47744
r9             0x0                 0
r10            0xbcc8              48328
r11            0x172e0             94944
r12            0x45                69
r13            0x407fdb28          0x407fdb28
r14            0x9154              37204
r15            0x9174              0x9174
0x407ffc48:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffc50:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffc58:	0x00	0x00	0x00	0x00	0x00	0x00	0x00	0x00
0x407ffc60:	0x00	0x00	0x00	0x00	0x00	0x00	0x00	0x00
0x407ffc68:	0x00	0x00	0x00	0x00	0x00	0x00	0x00	0x00
0x407ffc70:	0x00	0x00	0x00	0x00	0x00	0x00	0x00	0x00
0x407ffc78:	0x00	0x00	0x00	0x00	0x00	0x00	0x00	0x00
0x407ffc80:	0x00	0x00	0x00	0x00	0x00	0x00	0x00	0x00
0x407ffc88:	0x00	0x00	0x00	0x00	0x00	0x00	0x00	0x00
0x407ffc90:	0xcc	0xfc	0x7f	0x40	0x5c	0x8e	0x80	0x40
0x407ffc98:	0x00	0x00	0x00	0x00	0xe5	0xa2	0xc4	0x0c
0x407ffca0:	0x00	0x00	0x00	0x00	0xc4	0x25	0x82	0x40

[BP_0x918C_copy_done]
r0             0x14c60             85088
r1             0xbcc8              48328
r2             0xa                 10
r3             0x0                 0
r4             0xbcbc              48316
r5             0x407ffb58          1082129240
r6             0x100               256
r7             0x2bc               700
r8             0xba80              47744
r9             0x0                 0
r10            0xbcc8              48328
r11            0x172e0             94944
r12            0x45                69
r13            0x407fdb28          0x407fdb28
r14            0x9154              37204
r15            0x918c              0x918c
0x407ffc48:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffc50:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffc58:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffc60:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffc68:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffc70:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffc78:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffc80:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffc88:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffc90:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffc98:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffca0:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffc58:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffc60:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffc68:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffc70:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffc78:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffc80:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffc88:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffc90:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffc98:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffca0:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffca8:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffcb0:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffcb8:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffcc0:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffcc8:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41
0x407ffcd0:	0x41	0x41	0x41	0x41	0x41	0x41	0x41	0x41

[BP_0xA24C_call_sub90F0_date]
r0             0x1                 1
r1             0xbae9              47849
r2             0x41                65
r3             0x4e                78
r13            0x407fdb48          0x407fdb48
r14            0x919c              37276
r15            0xa24c              0xa24c

[BP_0x91D4_sscanf_sink]
r0             0x158b8             88248
r1             0xbaec              47852
r2             0x407ffb58          1082129240
r3             0x158b8             88248
r13            0x407fdb28          0x407fdb28
r14            0x9154              37204
r15            0x91d4              0x91d4
0xbaec:	"%*s %*s %s"

[BP_0x91D4_sscanf_sink]
r0             0x14f28             85800
r1             0xbaec              47852
r2             0x407ffb58          1082129240
r3             0x14f28             85800
r13            0x407fdb28          0x407fdb28
r14            0x9154              37204
r15            0x91d4              0x91d4
0xbaec:	"%*s %*s %s"

[BP_0x91D4_sscanf_sink]
r0             0x15b1c             88860
r1             0xbaec              47852
r2             0x407ffb58          1082129240
r3             0x15b1c             88860
r13            0x407fdb28          0x407fdb28
r14            0x9154              37204
r15            0x91d4              0x91d4
0xbaec:	"%*s %*s %s"

[BP_0x91D4_sscanf_sink]
r0             0x15654             87636
r1             0xbaec              47852
r2             0x407fdb00          1082120960
r3             0x15654             87636
r13            0x407fdae0          0x407fdae0
r14            0x9154              37204
r15            0x91d4              0x91d4
0xbaec:	"%*s %*s %s"

[BP_0x98B0_call_sub90F0_upstemp]
r0             0x1                 1
r1             0xbae9              47849
r2             0x41                65
r3             0x4e                78
r13            0x407fdb00          0x407fdb00
r14            0x919c              37276
r15            0x98b0              0x98b0
0xbae9:	"/A"

Program received signal SIGSEGV, Segmentation fault.
0x41414140 in ?? ()

```

![d002_gdb_evidence](E:\program\firmaware\multimon_9ad48d5b61db7b4296578c7df6b7c09924d5290d_submission_package\CNVD_Submission_zh.assets\d002_gdb_evidence.png)

## 12. 架构与解释器证据

```
/home/kali/Desktop/firmware-CNVD/target_binaries/tomato/9ad48d5b61db7b4296578c7df6b7c09924d5290d/www/apcupsd/multimon.cgi: ELF 32-bit LSB executable, ARM, EABI5 version 1 (SYSV), dynamically linked, interpreter /lib/ld-uClibc.so.0, stripped

Elf file type is EXEC (Executable file)
Entry point 0x8ccc
There are 6 program headers, starting at offset 52

Program Headers:
  Type           Offset   VirtAddr   PhysAddr   FileSiz MemSiz  Flg Align
  PHDR           0x000034 0x00008034 0x00008034 0x000c0 0x000c0 R E 0x4
  INTERP         0x0000f4 0x000080f4 0x000080f4 0x00014 0x00014 R   0x1
      [Requesting program interpreter: /lib/ld-uClibc.so.0]
  LOAD           0x000000 0x00008000 0x00008000 0x048a4 0x048a4 R E 0x8000
  LOAD           0x0048a4 0x000148a4 0x000148a4 0x00398 0x013d0 RW  0x8000
  DYNAMIC        0x0048b0 0x000148b0 0x000148b0 0x000d0 0x000d0 RW  0x4
  GNU_STACK      0x000000 0x00000000 0x00000000 0x00000 0x00000 RW  0x4

 Section to Segment mapping:
  Segment Sections...
   00     
   01     .interp 
   02     .interp .hash .dynsym .dynstr .rel.dyn .rel.plt .init .plt .text .fini .rodata .eh_frame 
   03     .init_array .fini_array .jcr .dynamic .got .data .bss 
   04     .dynamic 
   05     

```

