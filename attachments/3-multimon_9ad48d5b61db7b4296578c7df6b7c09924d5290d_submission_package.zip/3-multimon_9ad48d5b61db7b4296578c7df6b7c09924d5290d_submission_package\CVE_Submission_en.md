# CVE Submission Draft: Stack-Based Buffer Overflow in `multimon.cgi`

## 1. Proposed Title

Stack-based buffer overflow in `www/apcupsd/multimon.cgi` in `Tomato by Shibby` firmware

## 2. Affected Product

- Product family: `Tomato by Shibby`
- Affected component: `www/apcupsd/multimon.cgi`
- Verified affected sample:
  - hash: `9ad48d5b61db7b4296578c7df6b7c09924d5290d`
  - architecture: `ARM`
  - binary sha256: `68dac0594a1d9412aa48e01d6ea8dc843dc04f067eb3dbc7f1670e20d3f6ef50`

## 3. Vulnerability Type

- Stack-based Buffer Overflow
- Out-of-bounds Write
- CWE:
  - `CWE-121`
  - `CWE-787`

## 4. Vulnerability Description

`multimon.cgi` renders APC UPS monitoring data by connecting to configured UPS hosts and parsing the returned text fields into caller-supplied stack buffers.

The parsing helper `sub_90F0` contains two unsafe write paths:

- `0x9174`: newline-terminated byte-copy loop that does not enforce the caller-provided length
- `0x91d4`: `sscanf("%*s %*s %s", a3)` with an unbounded `%s`

Representative call sites include:

- `0x98b0`: `sub_90F0(..., "upstemp", ..., 0x40)`
- `0xa24c`: `sub_90F0(..., "date", ..., 0x100)`

An attacker-controlled UPS response field longer than the destination stack buffer causes memory corruption beyond the intended boundary.

## 5. Root Cause

The root cause is missing bounds enforcement in `sub_90F0` when parsing attacker-controlled UPS response fields.

- the caller passes a finite destination size such as `0x40` or `0x100`
- the parser selects a field from the UPS response
- the copy logic continues until newline, or `%s` consumes an arbitrarily long token
- no effective bounds check is applied before writing into the stack buffer

## 6. Attack Scenario / Preconditions

When `multimon.cgi` is requested, the program reads monitor targets from `usr/local/apcupsd/hosts.conf`, connects to the configured UPS service, sends the request body `status`, and parses the returned fields.

An attacker who can control or spoof the configured UPS endpoint can return oversized field values such as `DATE`, `ITEMP`, `LINEV`, `MINLINEV`, or `MAXLINEV` and trigger the overflow during page generation.

## 7. Runtime Verification

The issue was runtime-verified in QEMU with a matching rootfs and `gdb-multiarch`.

Observed evidence:

- the binary is an ARM ELF using interpreter `/lib/ld-uClibc.so.0`
- the fake UPS server received the request body `status`
- breakpoint `0xa24c` was hit on the `date` path (`a4 = 0x100`)
- breakpoint `0x98b0` was hit on a `0x40` caller path
- breakpoint `0x9174` was hit with:
  - `r6 = 0x100`
  - `r7 = 0x100`
  - this shows writing had already reached the exact declared buffer boundary
- breakpoint `0x918c` was hit after the copy completed with:
  - `r7 = 0x2bc` (700 bytes copied)
  - continuous attacker-controlled `0x41` bytes visible beyond `dest + 0x100`
- breakpoint `0x91d4` (`sscanf("%*s %*s %s")`) was hit 4 times
- execution ended in `SIGSEGV` with PC at `0x41414140`, showing control-flow corruption with attacker-controlled pattern bytes

## 8. Security Impact

This vulnerability can lead to:

- process crash / denial of service
- corruption of adjacent stack data
- corruption of saved registers or return address
- possible control-flow hijacking under favorable exploit conditions

## 9. Suggested Short CVE Description

A stack-based buffer overflow exists in `www/apcupsd/multimon.cgi` in `Tomato by Shibby` firmware because attacker-controlled UPS response fields are copied into fixed-size stack buffers without proper bounds checking, and the issue has been runtime-verified on an ARM sample.

## 10. Supporting Files

- dynamic verification summary: `d002_multimon_dynamic_verified.md`
- raw verification data: `d002_multimon_dynamic_verified.json`
- gdb transcript: `d002_gdb_capture.txt`
- gdb evidence image: `d002_gdb_evidence.png`
- file/readelf evidence: `d002_file_readelf.txt`

## 11. Note

This draft is based on one runtime-verified sample of `multimon.cgi`.
Before external submission, public advisory / existing CVE de-duplication should still be checked.
