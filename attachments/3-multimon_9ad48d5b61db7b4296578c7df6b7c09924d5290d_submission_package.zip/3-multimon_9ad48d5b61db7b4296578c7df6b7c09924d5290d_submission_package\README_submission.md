# `multimon.cgi` Submission Draft Package

This directory now includes submission-ready drafts for the verified `multimon.cgi` case:

- `CNVD_Submission_zh.md`
- `CVE_Submission_en.md`

Primary supporting files:

- `d002_multimon_dynamic_verified.md`
- `d002_multimon_dynamic_verified.json`
- `d002_gdb_capture.txt`
- `d002_gdb_evidence.png`
- `d002_file_readelf.txt`

Current status:

- verified in QEMU + gdb
- component: `www/apcupsd/multimon.cgi`
- verified sample hash: `9ad48d5b61db7b4296578c7df6b7c09924d5290d`
