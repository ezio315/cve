# SCEP Reply Path Verification Summary

Objective:

- confirm that the live RouterOS SCEP server reuses request `transactionID` values in `certRep` replies
- confirm that the reply-side path remains reachable through both `pending` and `success` states

Runtime environment:

- RouterOS `7.20.7` ARM64 system-level QEMU environment
- SCEP endpoint enabled at `/scep/`

Verified clean sample:

- `common-name`: `scep-clean-1`
- `transactionID`: `2153e85a90763000b53560a9d9ff5153c76ac16d0445f8c1886f8e404fd7f210`
- issued certificate serial: `584FDBDDAB6DCFA5`

Observed sequence:

1. At `15:08:51`, the server parses the `PKCS#10 request (19)` and emits `certRep (3)` with `status: pending (3)` for the same `transactionID`.
2. At `15:08:53`, the operator grants the enrollment transaction with the same `transactionID`.
3. At `15:09:21`, the client polls `getCertInitial (20)` using the same `transactionID`.
4. At `15:09:22`, the server logs:
   - `generated certificate 584FDBDDAB6DCFA5:scep-clean-1`
   - `packet encoding message type: certRep (3)`
   - `packet transaction: 2153e85a90763000b53560a9d9ff5153c76ac16d0445f8c1886f8e404fd7f210`
   - `scep-clean-1 certificate updated`

Offline success-reply checks:

- the logged success `certRep` contains `messageType=certRep (3)`
- the logged success `certRep` contains `pkiStatus=success (0)`
- the logged success `certRep` contains `senderNonce`, `recipientNonce`, and `transactionID`
- the ASCII-encoded `transactionID` is present inside the success reply body

Conclusion:

- request `transactionID` values reach the live reply-construction path
- the runtime behavior matches the `createReplyFrom` -> `encodeSignerInfo` -> `addPString` path described in `report.md`
- this document establishes reply-path reachability and reply-side reuse of attacker-controlled `transactionID` values
