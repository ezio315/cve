# MikroTik `scep.p` Static Root Cause Summary

Target sample:

- official firmware line: `routeros-arm-6.49.8.npk`
- vulnerable component: `nova/lib/www/scep.p`
- architecture: ARM 32-bit EABI5

Relevant function chain:

| Function | Address | Role |
| --- | --- | --- |
| `PKIMessage::getPString` | `0x96e8` | returns `ASN1_STRING_data()` for signed attributes |
| `PKIMessage::decodeSignerInfo` | `0xb248` | consumes `messageType`, `transactionID`, `pkiStatus`, and `failInfo` before signature verification |
| `PKIMessage::createReplyFrom` | `0x9be4` | copies request `transactionID` into the reply object |
| `PKIMessage::encodeSignerInfo` | `0xa468` | serializes reply-side signed attributes |
| `PKIMessage::addPString` | `0x13e20` | calls `ASN1_STRING_set(..., -1)` and therefore relies on `strlen()` |

Key observations:

1. `PKIMessage::getPString` returns the raw `ASN1_STRING_data()` pointer and does not preserve the original ASN.1 length.
2. `PKIMessage::decodeSignerInfo` consumes attacker-controlled signed attributes with C-string semantics before trust is established:
   - `atoi()` for `messageType`
   - `string::assign()` for `transactionID`
   - `atoi()` again for optional `pkiStatus` and `failInfo`
3. The reply path copies the same `transactionID` into the response object and re-encodes it through `ASN1_STRING_set(..., -1)`, which derives length from `strlen()` rather than from a trusted ASN.1 length.

Security meaning:

- A length-valid but non-NUL-terminated ASN.1 `PRINTABLESTRING` can be read past its intended boundary.
- Because the same attacker-controlled value is later reused during `certRep` construction, the over-read data can influence reply encoding.
- The vulnerable parsing path is reached before signature verification, which makes the issue pre-authentication.

Conclusion:

- This is the static basis for the `CWE-125` / `CWE-130` issue described in `report.md`.
