# Reproduction Artifacts

Bundled files:

- `chr_7.20.7_scep_client_pkio_body.der`
  - baseline CMS/PKCS#7 `PKIOperation` request body reconstructed from the archived RouterOS certificate debug log
- `chr_7.20.7_scep_client_pkio_body_txid_mut.der`
  - same body with the first byte of `transactionID` changed from `0x63` (`c`) to `0x5a` (`Z`)
- `chr_7.20.7_scep_client_pkio_asn1.txt`
  - `openssl asn1parse` output for the baseline body

Attribute location:

- `transactionID` object offset: `1537`
- ASN.1 header length: `2`
- first content byte offset: `1539`

Replay example:

```bash
curl -sS -X POST "http://127.0.0.1/scep/?operation=PKIOperation" \
  -H "Content-Type: application/x-pki-message" \
  --data-binary @./repro/chr_7.20.7_scep_client_pkio_body_txid_mut.der
```

Expected observation:

- the server logs the attacker-controlled `transactionID` value before reporting `signed attribute signature not matching`
- a clean baseline request shows that the same `transactionID` is later reused in `certRep pending` and `certRep success`
