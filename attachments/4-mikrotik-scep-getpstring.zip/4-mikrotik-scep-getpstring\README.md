# MikroTik `scep.p` CVE Package

This directory is organized as a small submission bundle for the verified `scep.p` signed-attribute length-confusion issue.

Included files:

- `report.md`
  - main CVE-oriented write-up
- `supporting/static_root_cause.md`
  - concise static root-cause summary for the `getPString` -> reply-path chain
- `supporting/response_path_verified.md`
  - concise runtime summary showing that request `transactionID` values reach `certRep` replies
- `repro/README.md`
  - notes for the bundled reproduction artifacts
- `repro/chr_7.20.7_scep_client_pkio_body.der`
  - baseline CMS/PKCS#7 `PKIOperation` request body reconstructed from RouterOS debug logs
- `repro/chr_7.20.7_scep_client_pkio_body_txid_mut.der`
  - minimal mutation that changes the first byte of `transactionID` from `c` to `Z`
- `repro/chr_7.20.7_scep_client_pkio_asn1.txt`
  - `openssl asn1parse` output for the baseline request body

Notes:

- All paths referenced from `report.md` are relative to this directory.
- Verbose QEMU probes, raw logs, host-side hooks, and feasibility notes were moved to `../../archive/working_notes/mikrotik-scep-getpstring/`.
