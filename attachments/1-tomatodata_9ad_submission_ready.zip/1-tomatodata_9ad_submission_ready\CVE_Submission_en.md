# CVE Submission Draft: Stack-Based Buffer Overflow in `tomatodata.cgi`

## 1. Proposed Title

Stack-based buffer overflow in `www/apcupsd/tomatodata.cgi` in `Tomato by Shibby` firmware

## 2. Affected Product

- Product family: `Tomato by Shibby` firmware
- Verified firmware image hash: `9ad48d5b61db7b4296578c7df6b7c09924d5290d`
- Affected component: `www/apcupsd/tomatodata.cgi`

## 3. Vulnerability Type

- Stack-based Buffer Overflow
- Out-of-bounds Write
- CWE:
  - `CWE-121`
  - `CWE-787`

## 4. Vulnerability Description

`tomatodata.cgi` retrieves UPS information and parses the UPS response field identified as `DATE`.  
In the verified sample, `cgi_main()` calls:

```c
get_ups_field(host, "date", &stack_buf, 0x100);
```

where `stack_buf` is a 256-byte stack buffer.

The `date` field maps to the `DATE` token with `mode=0`, which forces execution into the unbounded byte-copy path in `get_ups_field()` at `0x9040`. That path copies bytes until a newline is encountered and does not enforce the caller-provided length argument `a4`.

As a result, an attacker-controlled `DATE` field longer than 256 bytes causes an out-of-bounds write on the stack.

## 5. Root Cause

The root cause is improper bounds checking in `get_ups_field()`:

- caller buffer size: `0x100`
- dangerous sink: unbounded byte-copy loop at `0x9040`
- stop condition: newline only
- missing protection: no check against `a4`

This allows attacker-controlled UPS response data to overwrite memory beyond the destination stack buffer.

## 6. Reproduction Summary

Environment used for verification:

- `qemu-arm`
- runtime rootfs extracted from the matching firmware image

Input conditions:

- `QUERY_STRING='host=127.0.0.1&refresh=1'`
- a fake UPS server returning a 512-byte `DATE` field

Observed behavior:

- the target requests `status` from the fake UPS server
- the CGI successfully processes the attacker-controlled `DATE` field
- `gdb` confirms the destination buffer size is `0x100`
- bytes `0x41` are still present at `dest+0x100`, proving an out-of-bounds write beyond the 256-byte stack buffer

## 7. Runtime Evidence

At breakpoint `0x8FAC`:

- `r1 = "date"`
- `r2 = 0x40800180`
- `r3 = 0x100`

At breakpoint `0x9048`:

- `x/64bx $dest` shows continuous `0x41`
- `x/64bx $dest+0x100` still shows continuous `0x41`

Backtrace output includes:

- `corrupt stack?`

## 8. Evidence Screenshot

![gdb overflow evidence](./evidence/gdb_overflow_evidence.png)

Figure 1 shows that the controlled `0x41` bytes continue beyond `dest+0x100`, which is direct runtime evidence of a stack out-of-bounds write.

## 9. Impact

This vulnerability can lead to:

- process crash / denial of service
- corruption of stack-resident data
- possible saved register / return-address corruption
- possible control-flow hijacking under favorable conditions

## 10. Suggested Short CVE Description

A stack-based buffer overflow exists in `www/apcupsd/tomatodata.cgi` in `Tomato by Shibby` firmware because an attacker-controlled UPS `DATE` response field is copied into a 256-byte stack buffer without bounds checking in `get_ups_field()`.

## 11. Supporting File

- Raw dynamic verification output: `supporting/tomatodata_9ad_dynamic_verified.md`

## 12. Note

The vulnerability is technically verified.  
Before final external submission, public-advisory and existing-CVE de-duplication should still be checked to avoid duplicate reporting.
