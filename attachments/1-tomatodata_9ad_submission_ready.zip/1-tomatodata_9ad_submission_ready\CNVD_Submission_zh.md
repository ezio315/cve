# `tomatodata.cgi` 栈溢出

## 1. 漏洞标题

`Tomato by Shibby` 固件 `www/apcupsd/tomatodata.cgi` 组件存在栈溢出漏洞

## 2. 基本信息

- 厂商/产品：`Tomato by Shibby` 固件家族
- 已验证样本：固件镜像哈希 `9ad48d5b61db7b4296578c7df6b7c09924d5290d`
- 受影响组件：`www/apcupsd/tomatodata.cgi`
- 漏洞类型：栈溢出 / 越界写
- CWE：
  - `CWE-121` Stack-based Buffer Overflow
  - `CWE-787` Out-of-bounds Write
- 风险等级建议：高危
- 利用条件：攻击者可控制 UPS 响应中的 `DATE` 字段内容，并使目标 CGI 对该 UPS 主机发起查询

## 3. 漏洞描述

`tomatodata.cgi` 在处理 UPS 返回数据时，会调用 `get_ups_field(host, "date", buf, 0x100)` 提取 `DATE` 字段。  
其中目标缓冲区 `buf` 位于栈上，大小仅为 `0x100`（256）字节。

对 `date` 字段的解析实际命中 `get_ups_field()` 中的无界逐字节复制分支：

- 字段映射：`date -> "DATE" -> mode=0`
- 危险地址：`0x9040`
- 复制逻辑：持续复制直到遇到 `'\n'`
- 问题点：复制过程中**不检查调用方提供的长度参数 `a4`**

因此，当攻击者控制的 `DATE` 字段长度超过 256 字节时，会发生越界写，覆盖栈上相邻数据，形成栈溢出。

## 4. 成因分析

关键链路如下：

- `parse_query_string()`：从 `QUERY_STRING` 解析 `host`
- `is_host_authorized()`：检查目标 host 是否被允许
- `cgi_main()`：调用 `get_ups_field(host, "date", &stack_buf, 0x100)`
- `get_ups_field()`：在 `0x9040` 将 `DATE` 字段写入 256 字节栈缓冲区

其中：

- `cgi_main@0x96d4` 明确传入缓冲区大小 `0x100`
- `get_ups_field@0x9040` 对 `date` 字段走无界复制路径
- 复制停止条件仅为遇到换行符，不受 `a4=0x100` 限制

## 5. 复现概述

复现环境：

- `qemu-arm`
- 运行时根文件系统来自：
  - `unpacked/tomato/9ad48d5b61db7b4296578c7df6b7c09924d5290d.trx`

复现输入：

- `QUERY_STRING='host=127.0.0.1&refresh=1'`
- Fake UPS 返回 512 字节 `DATE` 字段

复现结果：

- 目标向 Fake UPS 发送请求体 `status`
- CGI 成功回显超长 `DATE` 字段
- 在 `gdb` 中确认目标缓冲区大小为 `0x100`
- 在 `dest+0x100` 处仍能看到连续 `0x41`，证明越界写已发生

## 6. 关键证据

### 6.1 运行时证据摘要

- `0x8FAC` 断点处：
  - `r1 = "date"`
  - `r2 = 0x40800180`
  - `r3 = 0x100`
- `0x9048` 断点处：
  - `x/64bx $dest` 为连续 `0x41`
  - `x/64bx $dest+0x100` 仍为连续 `0x41`
- `bt` 输出：
  - `Backtrace stopped: previous frame identical to this frame (corrupt stack?)`

### 6.2 截图证据

![gdb overflow evidence](./evidence/gdb_overflow_evidence.png)

图 1：`gdb` 现场证据显示：

- 目标缓冲区大小为 `0x100`
- 边界外 `dest+0x100` 仍被攻击者可控字节 `0x41` 覆盖
- 调用栈出现 `corrupt stack` 提示

## 7. 安全影响

该漏洞属于高危内存破坏漏洞，可能导致：

- CGI 进程崩溃
- 栈上局部变量、保存寄存器或返回地址被破坏
- 在特定内存布局与利用条件下，存在进一步控制执行流的可能

## 8. 修复建议

- 在 `get_ups_field()` 中对所有写入路径统一做边界检查
- 对 `%s` 类解析使用显式长度限制
- 对按分隔符复制的循环使用剩余空间计数
- 若字段超长，应截断或直接报错返回
- 建议同时复核 `apcupsd` 相关兄弟 CGI 组件是否存在同类问题

## 9. 原始动态结果

- binary: `/home/kali/Desktop/firmware-CNVD/_firmware_runtime/unpacked/tomato/9ad48d5b61db7b4296578c7df6b7c09924d5290d.trx/www/apcupsd/tomatodata.cgi`
- rootfs: `/home/kali/Desktop/firmware-CNVD/_firmware_runtime/unpacked/tomato/9ad48d5b61db7b4296578c7df6b7c09924d5290d.trx`
- return_code: `0`
- contains_date_echo: `True`
- contains_unable_msg: `False`

### Server State

```json
{
  "server_ready": true,
  "client": "127.0.0.1:40846",
  "request_len": 6,
  "request_body_ascii": "status",
  "request_body_hex": "737461747573",
  "payload_sent": true
}
```

### stdout

```text
<blockquote><pre>DATE     : AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
END APC      : 1
</pre></blockquote>

```

### stderr

```text

```

