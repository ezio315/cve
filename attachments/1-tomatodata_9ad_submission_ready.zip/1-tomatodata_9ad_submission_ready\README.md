# `tomatodata.cgi` Submission Package

This directory is the cleaned, submission-ready package for the verified `tomatodata.cgi` stack overflow case.

Use:

- `CNVD_Submission_zh.md` for CNVD / 中文提交流程
- `CVE_Submission_en.md` for CVE / English submission

Included files:

- `evidence/gdb_overflow_evidence.png`
  - Runtime proof screenshot showing writes beyond the `0x100` stack buffer boundary
- `supporting/tomatodata_9ad_dynamic_verified.md`
  - Raw QEMU dynamic verification output summary

Verified sample:

- Firmware family: `Tomato by Shibby`
- Verified firmware image hash: `9ad48d5b61db7b4296578c7df6b7c09924d5290d`
- Affected component: `www/apcupsd/tomatodata.cgi`

Current status:

- Vulnerability type is confirmed as a stack-based buffer overflow / out-of-bounds write
- Runtime `gdb` evidence has been captured
- Public disclosure / existing CVE de-duplication should still be checked before final external submission wording is frozen
